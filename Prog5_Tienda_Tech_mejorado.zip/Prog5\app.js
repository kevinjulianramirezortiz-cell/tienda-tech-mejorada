/* Tienda Tech: mejoras de interacción en el navegador. */
(() => {
  "use strict";

  const form = document.querySelector("#form-producto");
  const fileInput = form?.querySelector('input[name="imagen"]');
  const previewBox = document.querySelector("#vista-previa-imagen");
  const previewImage = document.querySelector("#imagen-seleccionada");
  const previewName = document.querySelector("#nombre-imagen");
  const formStatus = document.querySelector("#estado-formulario");
  let currentPreviewUrl = null;

  const normalizar = (texto) => texto
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("es");

  // Filtra al escribir sin recargar la página; el formulario GET sigue disponible.
  const searchInput = document.querySelector("#busqueda-productos");
  const categoryInput = document.querySelector("#filtro-categoria");
  const cards = [...document.querySelectorAll("#lista-productos .producto")];
  const resultCount = document.querySelector("#cuenta-resultados");
  const initialEmpty = document.querySelector("#vacio-inicial");
  const noResults = document.querySelector("#sin-resultados");

  function filtrarProductos() {
    const query = normalizar(searchInput?.value.trim() ?? "");
    const category = normalizar(categoryInput?.value ?? "");
    let visible = 0;

    cards.forEach((card) => {
      const content = normalizar(card.querySelector(".info")?.textContent ?? "");
      const cardCategory = normalizar(card.dataset.categoria ?? "");
      const matches = content.includes(query) && (!category || cardCategory === category);
      card.hidden = !matches;
      if (matches) visible += 1;
    });

    if (resultCount) {
      resultCount.textContent = `${visible} resultado${visible === 1 ? "" : "s"}`;
    }
    const filtering = Boolean(query || category);
    if (initialEmpty) initialEmpty.hidden = filtering;
    if (noResults) noResults.hidden = !filtering || visible !== 0;
  }

  searchInput?.addEventListener("input", filtrarProductos);
  categoryInput?.addEventListener("change", filtrarProductos);
  filtrarProductos();

  // Muestra una miniatura local y valida el formato y el límite de 3 MB.
  fileInput?.addEventListener("change", () => {
    const file = fileInput.files?.[0];
    fileInput.setCustomValidity("");
    if (currentPreviewUrl) URL.revokeObjectURL(currentPreviewUrl);
    currentPreviewUrl = null;

    if (!file) {
      previewBox.hidden = true;
      previewImage.removeAttribute("src");
      previewName.textContent = "";
      return;
    }

    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!allowedTypes.includes(file.type)) {
      fileInput.setCustomValidity("Elige una imagen JPG, PNG, WEBP o GIF.");
      formStatus.textContent = fileInput.validationMessage;
      previewBox.hidden = true;
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      fileInput.setCustomValidity("La imagen no puede superar los 3 MB.");
      formStatus.textContent = fileInput.validationMessage;
      previewBox.hidden = true;
      return;
    }

    currentPreviewUrl = URL.createObjectURL(file);
    previewImage.src = currentPreviewUrl;
    previewName.textContent = `${file.name} · ${(file.size / 1024 / 1024).toFixed(2)} MB`;
    previewBox.hidden = false;
    formStatus.textContent = "";
  });

  // Repite reglas básicas del servidor y explica el error antes de enviar.
  form?.addEventListener("submit", (event) => {
    const name = form.elements.namedItem("nombre");
    const price = form.elements.namedItem("precio");
    const stock = form.elements.namedItem("stock");
    const numericPrice = Number(price.value);
    const numericStock = Number(stock.value);

    name.setCustomValidity(name.value.trim() ? "" : "Escribe el nombre del producto.");
    price.setCustomValidity(
      price.value !== "" && Number.isFinite(numericPrice) && numericPrice >= 0
        ? ""
        : "El precio debe ser un número mayor o igual a cero."
    );
    stock.setCustomValidity(
      stock.value !== "" && Number.isInteger(numericStock) && numericStock >= 0
        ? ""
        : "El stock debe ser un entero mayor o igual a cero."
    );

    if (!form.checkValidity()) {
      event.preventDefault();
      form.reportValidity();
      formStatus.textContent = "Revisa los campos señalados antes de guardar.";
      return;
    }

    formStatus.textContent = "Enviando el producto…";
  });

  form?.addEventListener("input", (event) => {
    if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
      event.target.setCustomValidity("");
      if (!fileInput?.validationMessage) formStatus.textContent = "";
    }
  });

  window.addEventListener("pagehide", () => {
    if (currentPreviewUrl) URL.revokeObjectURL(currentPreviewUrl);
  });
})();
