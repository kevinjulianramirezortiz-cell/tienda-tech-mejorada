-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-10-2026 a las 03:20:47
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_tech`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `imagen_ruta` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `categoria`, `precio`, `stock`, `descripcion`, `imagen_ruta`) VALUES
(3, 'Oppo A78', 'Electronica', 2500.00, 22, NULL, NULL),
(4, 'REDMAGIC Golden Saga Limited Edition 10 Pro', 'Electronica', 31000.00, 15, NULL, '33aa5a2699c00893.webp'),
(5, 'audifonos infinix buds 5', 'electronica', 700.00, 15, NULL, NULL),
(6, 'aretes de oro de 24k', 'Accesorios', 750.00, 40, NULL, NULL),
(7, 'cargador del oppo a78', 'Electronica', 600.00, 10, NULL, NULL),
(8, 'tv 54 pulgadas', 'Electronica', 3000.00, 20, 'puede ser usada para tv normal no como monitor', NULL),
(9, 'pendientes de plata', 'Accesorios', 500.00, 9, 'pendientes echos de plata pura', NULL),
(10, 'Aire acondicionado 1 tonelada', 'linea blanca', 7000.00, 0, 'Aire acondicionada de una tonelada, perfecto para tu negocio', NULL),
(11, 'tenis Nike Jordan', 'Moda', 1200.00, 10, '¿Necesitas un nuevo estilo?\r\nEstos tenis te daran un nuevovestiloo perfecto para salir de la rutina y relajarte de los pendientes.', NULL),
(12, 'Calcetas anti deportivas', 'Deportes', 150.00, 10, 'Estas calecetas comodass perfectas para tus retas y tener un agarre firme al momento de jugar', NULL),
(13, 'mouse atack shark', 'Electronica', 1499.00, 7, NULL, NULL),
(14, 'teclado mecanico viper v4 pro', 'Electronica', 4599.00, 12, NULL, NULL),
(15, 'viper v3 pro', 'Electronica', 2199.00, 199, NULL, NULL),
(16, 'Pantalla LG', 'Electronica', 2500.20, 2, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
