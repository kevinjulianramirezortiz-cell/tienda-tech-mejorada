# Tienda Tech

Sistema web de inventario para Programación 5. La aplicación usa PHP, MySQL y JavaScript; permite registrar productos, editar y eliminar registros, filtrar por categoría y disponibilidad, consultar estadísticas y exportar el inventario a CSV.

## Requisitos

- XAMPP con Apache, MySQL/MariaDB y PHP 8 o posterior.
- Un navegador actualizado.

## Instalación local

1. Copia la carpeta `Prog5` dentro de `C:\xampp\htdocs\`.
2. Abre XAMPP e inicia **Apache** y **MySQL**.
3. En phpMyAdmin, importa `tienda_tech.sql`. Este archivo crea la base `tienda_tech`, la tabla `productos` y la tabla `usuarios`.
4. Si MySQL usa otros datos de acceso, actualiza el arreglo `$config` en `conexion.php`. La configuración incluida utiliza `127.0.0.1`, puerto `3306`, usuario `root` y contraseña vacía, que es el valor habitual de una instalación local de XAMPP.
5. Abre `http://localhost/Prog5/` en el navegador.

`productos.sql` contiene registros de ejemplo. Puedes importarlo después de crear la tabla si deseas poblar el inventario.

## Mejoras de JavaScript

- Búsqueda inmediata por nombre, categoría y descripción, junto con el filtro de categoría.
- Conteo de resultados y mensaje cuando la búsqueda no encuentra coincidencias.
- Validación del nombre, precio, stock, formato y tamaño de la imagen antes de enviar el formulario.
- Vista previa local de la imagen seleccionada.

La validación de JavaScript ayuda al usuario antes del envío; PHP y MySQL siguen procesando y guardando los datos. `app.js` no reemplaza la validación del servidor.

## Archivos principales

- `index.php`: interfaz de inventario y operaciones de productos.
- `app.js`: búsqueda, validación y vista previa de imágenes.
- `estilos.css`: diseño visual adaptable a pantallas pequeñas.
- `conexion.php`: conexión PDO a MySQL.
- `tienda_tech.sql`: estructura inicial de la base de datos.
